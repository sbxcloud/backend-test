/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prueba;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author sbxro
 */
@Entity
@Table(name = "PRODUCTOS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Productos.findAll", query = "SELECT p FROM Productos p")
    , @NamedQuery(name = "Productos.findByIdproductos", query = "SELECT p FROM Productos p WHERE p.idproductos = :idproductos")
    , @NamedQuery(name = "Productos.findByProductosName", query = "SELECT p FROM Productos p WHERE p.productosName = :productosName")
    , @NamedQuery(name = "Productos.findByProductosCod", query = "SELECT p FROM Productos p WHERE p.productosCod = :productosCod")
    , @NamedQuery(name = "Productos.findByProductosDes", query = "SELECT p FROM Productos p WHERE p.productosDes = :productosDes")
    , @NamedQuery(name = "Productos.findByProductosPrice", query = "SELECT p FROM Productos p WHERE p.productosPrice = :productosPrice")})
public class Productos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idproductos")
    private Integer idproductos;
    @Size(max = 45)
    @Column(name = "productosName")
    private String productosName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "productosCod")
    private String productosCod;
    @Size(max = 45)
    @Column(name = "productosDes")
    private String productosDes;
    @Column(name = "productosPrice")
    private Integer productosPrice;
    @JoinColumn(name = "id_tiendas", referencedColumnName = "idtienda")
    @ManyToOne
    private Tienda idTiendas;

    public Productos() {
    }

    public Productos(Integer idproductos) {
        this.idproductos = idproductos;
    }

    public Productos(Integer idproductos, String productosCod) {
        this.idproductos = idproductos;
        this.productosCod = productosCod;
    }

    public Integer getIdproductos() {
        return idproductos;
    }

    public void setIdproductos(Integer idproductos) {
        this.idproductos = idproductos;
    }

    public String getProductosName() {
        return productosName;
    }

    public void setProductosName(String productosName) {
        this.productosName = productosName;
    }

    public String getProductosCod() {
        return productosCod;
    }

    public void setProductosCod(String productosCod) {
        this.productosCod = productosCod;
    }

    public String getProductosDes() {
        return productosDes;
    }

    public void setProductosDes(String productosDes) {
        this.productosDes = productosDes;
    }

    public Integer getProductosPrice() {
        return productosPrice;
    }

    public void setProductosPrice(Integer productosPrice) {
        this.productosPrice = productosPrice;
    }

    public Tienda getIdTiendas() {
        return idTiendas;
    }

    public void setIdTiendas(Tienda idTiendas) {
        this.idTiendas = idTiendas;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idproductos != null ? idproductos.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Productos)) {
            return false;
        }
        Productos other = (Productos) object;
        if ((this.idproductos == null && other.idproductos != null) || (this.idproductos != null && !this.idproductos.equals(other.idproductos))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.prueba.Productos[ idproductos=" + idproductos + " ]";
    }
    
}
