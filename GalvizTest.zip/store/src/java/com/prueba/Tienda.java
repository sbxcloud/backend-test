/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prueba;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author sbxro
 */
@Entity
@Table(name = "TIENDA")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tienda.findAll", query = "SELECT t FROM Tienda t")
    , @NamedQuery(name = "Tienda.findByIdtienda", query = "SELECT t FROM Tienda t WHERE t.idtienda = :idtienda")
    , @NamedQuery(name = "Tienda.findByTiendaDir", query = "SELECT t FROM Tienda t WHERE t.tiendaDir = :tiendaDir")
    , @NamedQuery(name = "Tienda.findByTiendaTel", query = "SELECT t FROM Tienda t WHERE t.tiendaTel = :tiendaTel")})
public class Tienda implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtienda")
    private Integer idtienda;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "tiendaDir")
    private String tiendaDir;
    @Basic(optional = false)
    @NotNull
    @Column(name = "tiendaTel")
    private int tiendaTel;
    @OneToMany(mappedBy = "idTiendas")
    private Collection<Productos> productosCollection;
    @OneToMany(mappedBy = "idTienda")
    private Collection<Usuario> usuarioCollection;

    public Tienda() {
    }

    public Tienda(Integer idtienda) {
        this.idtienda = idtienda;
    }

    public Tienda(Integer idtienda, String tiendaDir, int tiendaTel) {
        this.idtienda = idtienda;
        this.tiendaDir = tiendaDir;
        this.tiendaTel = tiendaTel;
    }

    public Integer getIdtienda() {
        return idtienda;
    }

    public void setIdtienda(Integer idtienda) {
        this.idtienda = idtienda;
    }

    public String getTiendaDir() {
        return tiendaDir;
    }

    public void setTiendaDir(String tiendaDir) {
        this.tiendaDir = tiendaDir;
    }

    public int getTiendaTel() {
        return tiendaTel;
    }

    public void setTiendaTel(int tiendaTel) {
        this.tiendaTel = tiendaTel;
    }

    @XmlTransient
    public Collection<Productos> getProductosCollection() {
        return productosCollection;
    }

    public void setProductosCollection(Collection<Productos> productosCollection) {
        this.productosCollection = productosCollection;
    }

    @XmlTransient
    public Collection<Usuario> getUsuarioCollection() {
        return usuarioCollection;
    }

    public void setUsuarioCollection(Collection<Usuario> usuarioCollection) {
        this.usuarioCollection = usuarioCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtienda != null ? idtienda.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tienda)) {
            return false;
        }
        Tienda other = (Tienda) object;
        if ((this.idtienda == null && other.idtienda != null) || (this.idtienda != null && !this.idtienda.equals(other.idtienda))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.prueba.Tienda[ idtienda=" + idtienda + " ]";
    }
    
}
